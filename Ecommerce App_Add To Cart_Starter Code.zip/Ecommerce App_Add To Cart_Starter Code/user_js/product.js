var productCollection = JSON.parse(window.localStorage.getItem("product"));
var cartObj = JSON.parse(window.localStorage.getItem("cart"));
(function loadProductInformation(){
    var queryString = window.location.href;
    var productId = queryString.split("?")[1].split("=")[1];
    var productObj = productCollection[productId];

    let productText = generateProductText(productObj);
    let isProductInCart = checkProductInCart(productId);
    let productInCartQuantity = fetchProductQuantity(productId);

    let addToCartQtyNButton = '';
    if (isProductInCart === true)
    {
        productText += `<p style="background-color: #bbf2c9"> ${productInCartQuantity} units of product added in Cart </p>`;
    }
    else
    {
        productText += `<br/>`;
        addToCartQtyNButton = `<label for="quantity"> Quantity : </label> 
        <input type="number" id="quantity" class="quantity" min="1" max="100" value="${productInCartQuantity}">
        <button style="margin-right:16px" onclick="addProductToCart()">Add Product to Cart</button>`;
    }
    productText += `${addToCartQtyNButton} 
        <a href="../user_views/cart.html"><button>Go To Cart</button></a></div></div>`;

        document.getElementById("product-data").innerHTML = productText;

})();
function generateProductText(productObj)
{
    //Object Destructuring
    const {image,title,description,price, ...otherProductDetails} = { ...productObj};
   // let productText = '<div>'+productObj['titl']+'</div'
   // BACK TIC GRAVE ACCENT
   let productText = ` <img src="${image}" alt="Product"> 
                        <div class="info">
                        <div class="title"><b>Product Title : ${title} </b></div><br/>
                        <div class="description"> <b>Product Description</b><br/>${description}</div>
                        <div class="price"><br/>Price:$${price}</div><div>`;
                        return productText;

}
function checkProductInCart(productId=0)
{
    //productId =0;
    return (cartObj != null && productId in cartObj);
}
function fetchProductQuantity(productId = 0)
{
    if(checkProductInCart(productId))
    {
        return cartObj[productId]['quantity'];
    } 
    else{
        return 1;
    }
}
function addProductToCart() {
    var productId = window.location.href.split("?")[1].split("=")[1];
    let quantity = parseInt(document.getElementById("quantity").value);
// cart.js----cart.html
    let cartCollection = window.localStorage.getItem("cart");
    if(cartCollection)
    {
        cart = JSON.parse(cartCollection);
    }
    else{
        cart ={};
    }

    cart[productId] ={
        "productId":productId,
        "quantity":quantity
    }
    window.localStorage.setItem("cart",JSON.stringify(cart));
    location.reload();

}
//Function for loading Product Information on product.html page
/*
(function loadProductInformation() {
    var queryString = window.location.href;
    //Explain this step in detail
    var productId = queryString.split("?")[1].split("=")[1];
    var productObj = productCollection[productId];
    

    let productText = '<img src="' + productObj["image"] + '" alt="Product">' +
        '<div class="info">' +
        '<div class="title"><b>Product Title : ' + productObj["title"] + '</b></div><br/>' +
        '<div class="description"><b>Product Description: </b><br/>' + productObj["description"] + '</div>' +
        '<div class="price"><br/>Price : $' + productObj["price"] + '</div>' +
        '<div>';


    productText += '<label for="quantity">Quantity:</label>' +
        '<input type="number" id="quantity" class="quantity" min="1" max="100" value="' + 1 + '">' +
        '<button style="margin-right:16px">Add to Cart</button>' +
        '<a href="#"><button>Go to Cart</button></a>' +
        '</div>' +
        '</div>';

    document.getElementById("product-data").innerHTML = productText;
})();*/

